[root@ip-172-31-1-117 prometheus]# cat prometheus_install.sh 
#!/bin/bash

# Make prometheus user
sudo useradd --no-create-home -c "prometheus user" -s /bin/false prometheus

# Make directories necessary for prometheus
sudo mkdir -p /data/monitoring/prometheus/{data,config,bin,logs,rules}

# Assign ownership of the files above to prometheus user
sudo chown -R prometheus:prometheus /data/monitoring/prometheus

# Download prometheus and copy utilities to where they should be in the filesystem

VERSION=2.28.1
#echo "## Downloading Prometheus binary ##"
#curl -k -H "Host:artifactory.dev-test.axisb.com" -O https://127.0.0.1/artifactory/packages/prometheus
tar xvzf prometheus-${VERSION}.linux-amd64.tar.gz

sudo cp prometheus-${VERSION}.linux-amd64/prometheus /data/monitoring/prometheus/bin/
sudo cp prometheus-${VERSION}.linux-amd64/promtool /data/monitoring/prometheus/bin/
sudo cp -r prometheus-${VERSION}.linux-amd64/consoles /data/monitoring/prometheus
sudo cp -r prometheus-${VERSION}.linux-amd64/console_libraries /data/monitoring/prometheus

# Assign the ownership of the tools above to prometheus user
sudo chown -R prometheus:prometheus /data/monitoring/prometheus/consoles
sudo chown -R prometheus:prometheus /data/monitoring/prometheus/console_libraries
sudo chown prometheus:prometheus /data/monitoring/prometheus/bin/prometheus
sudo chown prometheus:prometheus /data/monitoring/prometheus/bin/promtool

# Populate configuration files
cat ./prometheus.yml | sudo tee /data/monitoring/prometheus/prometheus.yml
cat ./prometheus.rules.yml | sudo tee /data/monitoring/prometheus/rules/prometheus.rules.yml
cat ./prometheus.service | sudo tee /etc/systemd/system/prometheus.service

# systemd - Create service file for Prometheus
sudo systemctl daemon-reload
sudo systemctl enable prometheus
sudo systemctl start prometheus

# Installation cleanup
#rm prometheus-${VERSION}.linux-amd64.tar.gz
#rm -rf prometheus-${VERSION}.linux-amd64
